/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package worldofzuul;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author HCHB
 */
public class test {
    public static void main(String[] args) {
//    
//        //techDude
//            public Command getCommandDude() 
//    {
//        // Declare a String variable for the input
//        String inputLine;
//        
//       if (this.hasMetCharacter = false){
//           word1 = stay;
//           word2 = null;
//           word3 = null;
//           return new Command(commands.getCommandWord(word1), word2, word3);
//       }
//       else {
//           word1 = go;
//           word2 = null;
//           word3 = null;
//           return new Command(commands.getCommandWord(word1), word2, word3);
//           
//       }
//    }
//        
//        //zuul
//            public Command getCommandplayer() 
//    {
//        // Declare a String variable for the input
//        String inputLine;
//        
//        // Set words 1 and 2 to null
//        String word1 = null;
//        String word2 = null;
//        String word3 = null;
//        
//        String[] exits = zuul.getCurrentRoom().getExit().keySet().toArray();
//        
//        int numberMoveActions = exits.size()+1;
//        int action = (int)(Math.random()*numberMoveActions);
//        
//        ArrayList<String> exit1 = new ArrayList<>(Arrays.asList(exits));
//        
//        exit1.add("stay");    
//        
//        if (numberMoveActions == (action+1)){
//            word1 = "go";
//            word2 = exit1.get(action);
//        }
//        else {
//            word1 = exit1.get(action);
//        }
//        
//        // Create a Command object based on words 1 and 2, and return the command.
//        return new Command(commands.getCommandWord(word1), word2, word3);
//    }
//            
//            
//        
//        //Hero
//            public Command getCommandplayer() 
//    {
//        // Declare a String variable for the input
//        String inputLine;
//        
//        // Set words 1 and 2 to null
//        String word1 = null;
//        String word2 = null;
//        String word3 = null;
//
//        // Print "> " to prompt user input
//        System.out.print("> ");
//
//        // Use Scanner to read input line from user
//        inputLine = reader.nextLine();
//
//        // Create a Scanner called tokenizer based on inputLine
//        Scanner tokenizer = new Scanner(inputLine);
//        // If the input line has a first word, assign it to word1
//        if(tokenizer.hasNext()) {
//            word1 = tokenizer.next();
//            // If the input line has a second word, assign it to word2
//            if(tokenizer.hasNext()) {
//                word2 = tokenizer.next();
//                //if the input line has a third word assign it to word3
//                if(tokenizer.hasNext()) {
//                    word3 = tokenizer.next();
//                }
//            }
//        }
//
//        // Create a Command object based on words 1 and 2, and return the command.
//        return new Command(commands.getCommandWord(word1), word2, word3);
//    }
//        
//        
//        
//        
//        
//                
    }
    
}
